import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center mb-6">
              <div className="w-10 h-10 rounded-lg bg-purple-600 flex items-center justify-center mr-3">
                <span className="text-white font-bold text-xl">J</span>
              </div>
              <span className="font-bold text-xl tracking-tight text-white">
                江苏嘉德环境科技工程有限公司
              </span>
            </div>
            
            <p className="text-gray-400 mb-6">
              Crafting Digital Experiences that Inspire through innovative design and technical excellence.
            </p>
            
            <div className="flex space-x-4">
              <a href="#" className="bg-gray-800 hover:bg-purple-600 w-10 h-10 rounded-full flex items-center justify-center transition-colors" aria-label="Facebook">
                <i className="fa-brands fa-facebook-f"></i>
              </a>
              <a href="#" className="bg-gray-800 hover:bg-purple-600 w-10 h-10 rounded-full flex items-center justify-center transition-colors" aria-label="Twitter">
                <i className="fa-brands fa-twitter"></i>
              </a>
              <a href="#" className="bg-gray-800 hover:bg-purple-600 w-10 h-10 rounded-full flex items-center justify-center transition-colors" aria-label="Instagram">
                <i className="fa-brands fa-instagram"></i>
              </a>
              <a href="#" className="bg-gray-800 hover:bg-purple-600 w-10 h-10 rounded-full flex items-center justify-center transition-colors" aria-label="LinkedIn">
                <i className="fa-brands fa-linkedin-in"></i>
              </a>
            </div>
          </motion.div>
          
          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h4 className="font-bold text-lg mb-6 text-white">Quick Links</h4>
            <ul className="space-y-4">
              {['Home', 'About Us', 'Services', 'Portfolio', 'Blog', 'Contact'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors flex items-center">
                    <i className="fa-solid fa-arrow-right text-purple-500 mr-2"></i>
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>
          
          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h4 className="font-bold text-lg mb-6 text-white">Our Services</h4>
            <ul className="space-y-4">
              {['Web Design', 'Development', 'Branding', 'Digital Marketing', 'UI/UX Design', 'Consulting'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors flex items-center">
                    <i className="fa-solid fa-arrow-right text-purple-500 mr-2"></i>
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>
          
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h4 className="font-bold text-lg mb-6 text-white">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <i className="fa-solid fa-map-marker-alt text-purple-500 mt-1 mr-3"></i>
                <span className="text-gray-400">江苏省南京市建邺区江东中路311号中泰国际广场</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-phone text-purple-500 mr-3"></i>
                <span className="text-gray-400">+86 123 4567 8910</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-envelope text-purple-500 mr-3"></i>
                <span className="text-gray-400">contact@jiade-env.com</span>
              </li>
            </ul>
          </motion.div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} 江苏嘉德环境科技工程有限公司. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;