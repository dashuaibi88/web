import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const GuidingPrinciples = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Learn about the guiding principles that drive our studio to succeed.
          </h2>
          <div className="w-24 h-1 bg-purple-600 mx-auto mt-6 rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Our Core Values */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Core Values</h3>
              <p className="text-gray-600 mb-6">
                These fundamental principles guide everything we do and shape the experiences we create for our clients.
              </p>
              
              <div className="space-y-6">
                {/* Value 1 */}
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-lg text-purple-700 mt-1">
                    <i className="fa-solid fa-lightbulb text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg text-gray-900">Innovation</h4>
                    <p className="text-gray-600 mt-1">
                      We constantly push boundaries and explore new possibilities to create groundbreaking solutions.
                    </p>
                  </div>
                </div>
                
                {/* Value 2 */}
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-lg text-purple-700 mt-1">
                    <i className="fa-solid fa-users text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg text-gray-900">Collaboration</h4>
                    <p className="text-gray-600 mt-1">
                      We believe in the power of teamwork and work closely with our clients to achieve shared goals.
                    </p>
                  </div>
                </div>
                
                {/* Value 3 */}
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-lg text-purple-700 mt-1">
                    <i className="fa-solid fa-star text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg text-gray-900">Excellence</h4>
                    <p className="text-gray-600 mt-1">
                      We strive for perfection in every detail, delivering work that exceeds expectations.
                    </p>
                  </div>
                </div>
                
                {/* Value 4 */}
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-lg text-purple-700 mt-1">
                    <i className="fa-solid fa-heart text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg text-gray-900">Passion</h4>
                    <p className="text-gray-600 mt-1">
                      We love what we do, bringing energy and enthusiasm to every project we undertake.
                    </p>
                  </div>
                </div>
              </div>
              
              <button className="mt-8 inline-flex items-center px-6 py-3 border border-purple-600 text-purple-600 font-medium rounded-lg hover:bg-purple-600 hover:text-white transition-colors duration-300">
                Read More <i className="fa-solid fa-arrow-right ml-2"></i>
              </button>
            </div>
          </motion.div>
          
          {/* Right Column - Why We Do What We Do */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1559028006-44a08e38356b" 
                alt="Creative process and details" 
                className="w-full h-auto rounded-xl shadow-xl object-cover"
              />
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-purple-100 rounded-lg -z-10"></div>
            </div>
            
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Why We Do What We Do</h3>
              <p className="text-gray-600 mb-6">
                Our mission is driven by a deep-seated belief in the transformative power of great design.
              </p>
              
              <ul className="space-y-4 text-gray-700">
                <li className="flex items-start">
                  <i className="fa-solid fa-check text-purple-600 mt-1 mr-3"></i>
                  <span>We believe design should be accessible and meaningful to everyone.</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check text-purple-600 mt-1 mr-3"></i>
                  <span>We're passionate about solving complex problems through creative thinking.</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check text-purple-600 mt-1 mr-3"></i>
                  <span>We aim to create digital experiences that inspire and make a difference.</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check text-purple-600 mt-1 mr-3"></i>
                  <span>We're committed to sustainable practices and ethical design principles.</span>
                </li>
              </ul>
              
              <button className="mt-8 inline-flex items-center px-6 py-3 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors duration-300 shadow-md hover:shadow-lg">
                Get Started <i className="fa-solid fa-arrow-right ml-2"></i>
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default GuidingPrinciples;