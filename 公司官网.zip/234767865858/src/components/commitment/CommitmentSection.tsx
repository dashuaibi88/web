import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const CommitmentSection = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative z-10 rounded-xl overflow-hidden shadow-xl">
              <img 
                src="https://images.unsplash.com/photo-1516321497487-e288fb19713f" 
                alt="Team discussing project" 
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="absolute -top-6 -right-6 w-40 h-40 bg-purple-200 rounded-lg -z-10"></div>
            <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-purple-100 rounded-lg -z-10"></div>
          </motion.div>
          
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div>
              <span className="text-purple-600 font-semibold tracking-wide uppercase text-sm">Our Promise</span>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-6">
                Our Commitment to Excellence
              </h2>
              <div className="w-16 h-1 bg-purple-600 rounded-full mb-6"></div>
              
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                At 江苏嘉德环境科技工程有限公司, we're dedicated to delivering exceptional digital experiences that not only meet but exceed our clients' expectations. Our commitment to excellence is woven into every aspect of our work.
              </p>
              
              <p className="text-gray-600 mb-8 leading-relaxed">
                We believe that true excellence comes from a combination of creative vision, technical expertise, and unwavering attention to detail. Our team of designers and developers work collaboratively to ensure every project receives the care and consideration it deserves.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-full text-purple-700 mt-1">
                    <i className="fa-solid fa-check-circle"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Quality Craftsmanship</h4>
                    <p className="text-gray-600 text-sm mt-1">Meticulous attention to every detail</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-full text-purple-700 mt-1">
                    <i className="fa-solid fa-clock"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Timely Delivery</h4>
                    <p className="text-gray-600 text-sm mt-1">Respecting deadlines without compromise</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-full text-purple-700 mt-1">
                    <i className="fa-solid fa-comments"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Open Communication</h4>
                    <p className="text-gray-600 text-sm mt-1">Transparent process from start to finish</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-full text-purple-700 mt-1">
                    <i className="fa-solid fa-shield-alt"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Client Satisfaction</h4>
                    <p className="text-gray-600 text-sm mt-1">Your success is our ultimate goal</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default CommitmentSection;