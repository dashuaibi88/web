import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const HeroSection = () => {
  return (
    <section className="pt-24 md:pt-0 min-h-screen flex items-center bg-purple-900 text-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-6 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Excellence in everything we do
              </h1>
              <p className="text-xl md:text-2xl text-purple-100 mb-8 max-w-lg">
                Crafting Digital Experiences that Inspire through innovative design and technical excellence.
              </p>
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className="bg-white text-purple-900 px-8 py-3 rounded-lg font-medium text-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Learn More
            </motion.button>
          </motion.div>

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10 rounded-xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c" 
                alt="Team collaboration" 
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="absolute top-10 -right-10 w-64 h-64 bg-purple-700 rounded-full opacity-50 blur-3xl -z-10"></div>
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-purple-600 rounded-full opacity-50 blur-3xl -z-10"></div>
          </motion.div>
        </div>
        
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center animate-bounce">
          <span className="text-sm text-purple-200 mb-2">Scroll to explore</span>
          <i className="fa-solid fa-chevron-down text-purple-300"></i>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;