import { motion } from 'framer-motion';
import { useState } from 'react';
import { cn } from '@/lib/utils';

const Testimonials = () => {
  // Testimonial data
  const testimonials = [
    {
      id: 1,
      name: "张明",
      position: "市场总监, 科技创新有限公司",
      content: "与江苏嘉德环境科技工程有限公司合作是我们做过的最好决定之一。他们不仅理解我们的愿景，还将其转化为令人惊叹的数字体验，帮助我们实现了30%的用户增长。",
      avatar: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=portrait%20of%20middle-aged%20Asian%20man%20professional%20headshot&sign=100ccbc9f347de8181eb189b240d6910"
    },
    {
      id: 2,
      name: "李娜",
      position: "创始人, 未来设计工作室",
      content: "他们的创意能力和专业精神令人印象深刻。从概念到执行，整个过程无缝衔接，最终成果超出了我们的期望。强烈推荐他们的设计服务！",
      avatar: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=portrait%20of%20young%20Asian%20woman%20professional%20headshot&sign=3c69b09a8735f2f8c1d53e8fe861b574"
    },
    {
      id: 3,
      name: "王建国",
      position: "CEO, 绿色能源科技",
      content: "江苏嘉德环境科技工程有限公司不仅提供了出色的设计方案，还在项目过程中提供了宝贵的战略建议。他们真正成为了我们团队的延伸。",
      avatar: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=portrait%20of%20senior%20Asian%20man%20professional%20headshot&sign=2fe348732ca9a018bab25b0031c75bd1"
    }
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  // Handle next testimonial
  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  // Handle previous testimonial
  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Find out how we've made a difference for others
          </h2>
          <div className="w-20 h-1 bg-purple-600 mx-auto mt-6 rounded-full"></div>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {/* Testimonial Slider */}
          <div className="relative bg-white rounded-2xl shadow-xl p-8 md:p-12 overflow-hidden">
            {/* Background decoration */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-purple-50 rounded-full -translate-y-1/2 translate-x-1/2 -z-10"></div>
            
            {/* Testimonial content */}
            <motion.div
              key={testimonials[activeIndex].id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="text-center relative z-10"
            >
              <div className="text-purple-600 text-5xl mb-6">
                <i className="fa-solid fa-quote-left"></i>
              </div>
              
              <p className="text-xl md:text-2xl text-gray-700 italic mb-8 leading-relaxed">
                {testimonials[activeIndex].content}
              </p>
              
              <div className="flex items-center justify-center space-x-4">
                <img 
                  src={testimonials[activeIndex].avatar} 
                  alt={testimonials[activeIndex].name} 
                  className="w-16 h-16 rounded-full object-cover border-2 border-purple-100"
                />
                <div className="text-left">
                  <h4 className="font-bold text-gray-900 text-lg">{testimonials[activeIndex].name}</h4>
                  <p className="text-gray-600">{testimonials[activeIndex].position}</p>
                </div>
              </div>
            </motion.div>
            
            {/* Navigation buttons */}
            <button 
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white p-3 rounded-full shadow-md text-purple-600 hover:bg-purple-600 hover:text-white transition-colors"
              onClick={prevTestimonial}
              aria-label="Previous testimonial"
            >
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            
            <button 
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white p-3 rounded-full shadow-md text-purple-600 hover:bg-purple-600 hover:text-white transition-colors"
              onClick={nextTestimonial}
              aria-label="Next testimonial"
            >
              <i className="fa-solid fa-chevron-right"></i>
            </button>
            
            {/* Indicators */}
            <div className="flex justify-center space-x-2 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`w-3 h-3 rounded-full transition-all ${
                    activeIndex === index ? 'bg-purple-600 w-8' : 'bg-gray-300'
                  }`}
                  onClick={() => setActiveIndex(index)}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;