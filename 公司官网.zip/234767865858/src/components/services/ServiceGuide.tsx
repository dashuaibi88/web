import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const ServiceGuide = () => {
  // Service data
  const services = [
    {
      icon: 'fa-solid fa-comments',
      title: 'Consultation',
      description: 'We start by understanding your goals, challenges, and vision to create a tailored solution.'
    },
    {
      icon: 'fa-solid fa-palette',
      title: 'Design',
      description: 'Our creative team develops visually stunning concepts that align with your brand identity.'
    },
    {
      icon: 'fa-solid fa-code',
      title: 'Development',
      description: 'We transform designs into functional, responsive digital experiences using cutting-edge technologies.'
    },
    {
      icon: 'fa-solid fa-rocket',
      title: 'Launch & Support',
      description: 'We ensure a smooth deployment and provide ongoing support to help your project succeed.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            A quick and easy guide to using our service
          </h2>
          <p className="text-gray-600 text-lg">
            Our streamlined process ensures a smooth journey from concept to completion, delivering exceptional results every time.
          </p>
          <div className="w-20 h-1 bg-purple-600 mx-auto mt-6 rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 group hover:-translate-y-1 duration-300"
            >
              <div className="w-14 h-14 bg-purple-100 rounded-lg flex items-center justify-center text-purple-700 text-2xl mb-6 group-hover:bg-purple-600 group-hover:text-white transition-colors duration-300">
                <i className={service.icon}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <button className="inline-flex items-center px-8 py-4 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors duration-300 shadow-md hover:shadow-lg">
            Explore All Services <i className="fa-solid fa-arrow-right ml-2"></i>
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServiceGuide;