import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const ContactCTA = () => {
  return (
    <section className="py-24 bg-purple-900 text-white relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-800 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-700 rounded-full opacity-50 blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto text-center space-y-8"
        >
          <h2 className="text-3xl md:text-5xl font-bold leading-tight">
            Get in touch to see how we can help.
          </h2>
          
          <p className="text-xl text-purple-100">
            Ready to transform your digital presence? Let's discuss how we can create something amazing together.
          </p>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 300 }}
            className="bg-white text-purple-900 px-10 py-4 rounded-lg font-bold text-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            Contact Us
          </motion.button>
          
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-8 mt-8 text-purple-200">
            <div className="flex items-center space-x-3">
              <i className="fa-solid fa-envelope text-white"></i>
              <span>contact@jiade-env.com</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fa-solid fa-phone text-white"></i>
              <span>+86 123 4567 8910</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ContactCTA;