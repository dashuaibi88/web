import Navbar from '@/components/navbar/Navbar';
import HeroSection from '@/components/hero/HeroSection';
import GuidingPrinciples from '@/components/principles/GuidingPrinciples';
import CommitmentSection from '@/components/commitment/CommitmentSection';
import ServiceGuide from '@/components/services/ServiceGuide';
import Testimonials from '@/components/testimonials/Testimonials';
import ContactCTA from '@/components/contact/ContactCTA';
import Footer from '@/components/footer/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-900 overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <GuidingPrinciples />
      <CommitmentSection />
      <ServiceGuide />
      <Testimonials />
      <ContactCTA />
      <Footer />
    </div>
  );
}